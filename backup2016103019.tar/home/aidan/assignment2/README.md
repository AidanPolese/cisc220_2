# cisc220_2
Assignment 2 baby

It's going to get real crazy up in here
